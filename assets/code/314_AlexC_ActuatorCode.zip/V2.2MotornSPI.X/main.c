 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include <stdio.h>


 
#define MSGSIZE 65  // Define max message size
#define ACsystemID 0x63
#define AGsystemID 0x61
#define IAsystemID 0x69
#define KDsystemID 0x6B

#define startbyte1 0x41
#define startbyte2 0x5A

#define endbyte1 0x42
#define endbyte2 0x59

#define msgtype1 0x31
#define msgtype2 0x32
#define msgtype3 0x33
#define msgtype4 0x34
#define msgtype5 0x35
#define msgtype6 0x36

//stepper definitions
volatile int stepNum = 0;
int direction = 0;
volatile signed int inc = 0;






// callbac functon code
uint8_t buffer[2];
int i = 0;
int last_i = 0;
int incoming = 0;
uint8_t msg[65];
int msg_ii = 0;

//timer stuff
uint16_t time_ms = 0;
uint16_t time_s = 0;

//stepper stuff
uint16_t movecount = 0;








uint8_t msgtype;
uint8_t functionality = 0x31;

// SP stuff
char temp = 0;
uint8_t FWD = 0b11101111;
uint8_t REV = 0b11101101;
bool motor_turn;


uint8_t messageBuffer[MSGSIZE] = {0};  // Buffer to store incoming message
uint8_t messageIndex = 0;           // Index to track message length
int message_incoming = 0;      // Flag to indicate an active message

void sendString(const char* str) {
    while (*str) {
        while (!EUSART1_IsRxReady());  
        EUSART1_Write(*str++);
    }
}

void resetBuffer() {
    messageIndex = 0;
    for (int i = 0; i < MSGSIZE; i++) {
        msg[i]= 0x00;
    }
    for (int i = 0; i < MSGSIZE; i++) {
        messageBuffer[i]= 0x00;
    }
}
void rxReadyCallback(void) {
    if (EUSART1_IsRxReady() == 1) {
        buffer[i] = EUSART1_Read();

        if (buffer[last_i] == startbyte1 && buffer[i] == startbyte2) {
            incoming = 1;
            //LED2_SetHigh();
            msg[0] = buffer[last_i];
            msg_ii = 1;
        } else if (buffer[last_i] == endbyte2 && buffer[i] == endbyte1) {
            incoming = 0;
            //LED2_SetLow();
            msg[msg_ii-1] = buffer[last_i];
            msg[msg_ii] = buffer[i];
            message_incoming = 1;
        } else if (msg_ii >= 64) {
            incoming = 0;
            msg[62] = 0x59;
            msg[63] = 0x42;
            message_incoming = 1;
        }

        if (incoming == 1) {
            msg[msg_ii] = buffer[i];
            msg_ii++;
        }

        last_i = i;
        i++;
        if (i >=2) {
            i = 0;
        }
    }
}

int oneCharToInt(char c){
    return c - '0';
}
int twoCharToInt(char a,char b){
    return (a - '0') * 10 + (b - '0');
}
int threeCharToInt(char a, char b, char c){
    return (a - '0') * 100 + (b - '0') * 10 + (c - '0');
            
}
void substatuscode (){
    resetBuffer();
    messageBuffer[0] = startbyte1;
    messageBuffer[1] = startbyte2;
    messageBuffer[2] = ACsystemID;
    messageBuffer[3] = KDsystemID; // changed to kd system for checkoff
    messageBuffer[4] = msgtype3;
    messageBuffer[5] = functionality; 
    messageBuffer[6] = endbyte2;
    messageBuffer[7] = endbyte1;
    printf(messageBuffer);
}

void substatuserrormsg () {
    resetBuffer();
    messageBuffer[0] = startbyte1;
    messageBuffer[1] = startbyte2;
    messageBuffer[2] = ACsystemID;
    messageBuffer[3] = KDsystemID; // changed to kd system for checkoff
    messageBuffer[4] = msgtype4;
    messageBuffer[5] = 'N';
    messageBuffer[6] = 'o';
    messageBuffer[7] = 'e';
    messageBuffer[8] = 'r';
    messageBuffer[9] = 'r';
    messageBuffer[10] = 'o';
    messageBuffer[11] = 'r';    
    messageBuffer[12] = endbyte2;
    messageBuffer[13] = endbyte1;
    printf(messageBuffer);
}

void TimerCallback(void){
    
    time_ms ++;
    if (time_ms >= 1000){
        time_ms -= 1000;
        time_s++;
    }
    
    
}

float getTimeNow(void){
    
    float time = 0.0;
    time = ((float)time_s*1.0) + ((float)time_ms/1000.0);
    
    
    return time;
}

void stepStepper(void) {
    if (direction == 1){
        inc = 1;
    }
    else if (direction == 2){
        inc = -1;
    }
    switch (stepNum) {
        case 0:
        apos_SetHigh();
        aneg_SetLow();
        bpos_SetLow();
        bneg_SetLow();
        stepNum += inc;
        if (stepNum < 0) {stepNum = 7;}
        break;
        case 1:
        apos_SetHigh();
        aneg_SetLow();
        bpos_SetHigh();
        bneg_SetLow();
        stepNum += inc;
        break;
        case 2:
        apos_SetLow();
        aneg_SetLow();
        bpos_SetHigh();
        bneg_SetLow();
        stepNum += inc;
        break;
        case 3:
        apos_SetLow();
        aneg_SetHigh();
        bpos_SetHigh();
        bneg_SetLow();
        stepNum += inc;
        break;
        case 4:
        apos_SetLow();
        aneg_SetHigh();
        bpos_SetLow();
        bneg_SetLow();
        stepNum += inc;
        break;
        case 5:
        apos_SetLow();
        aneg_SetHigh();
        bpos_SetLow();
        bneg_SetHigh();
        stepNum += inc;
        break;
        case 6:
        apos_SetLow();
        aneg_SetLow();
        bpos_SetLow();
        bneg_SetHigh();
        stepNum += inc;
        break;
        case 7:
        apos_SetHigh();
        aneg_SetLow();
        bpos_SetLow();
        bneg_SetHigh();
        stepNum += inc;
        if (stepNum > 7) {stepNum = 0;}
        break;
    }
}






int result;



void main(void) {
    
    
    
    
    // Initialize the device

    
   
    SYSTEM_Initialize();
    EUSART1_Initialize();
    
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    EUSART1_ReceiveInterruptEnable();
    
    
    
    EUSART1_RxCompleteCallbackRegister(rxReadyCallback);
    TMR0_OverflowCallbackRegister(TimerCallback);
    
    
    SPI1_Initialize();
    SPI1_Open(HOST_CONFIG);
    uint8_t FWD = 0b11101111;
    uint8_t REV = 0b11101101;
    uint8_t STP = 0b11101100;
    
            
            
    int motorin;
    int stepperin;
    char temp = 0;
    uint8_t motorAngle;
    uint8_t alignfreq;
    
    //timer variables 
    
    float currentTime = 0.0;
    float passedTime = 0.0;
    
    float lastStepTime = 0.0;
    
    
   //stepper stuff
    
    float stepDelay = 0.0;
    stepDelay = 375.0 / 128000.0;
    uint16_t stepcount = 0;
    
    //photo read values
    
    int photoread[3];
    float motorTime = 0.0;
    float checTime = 0.0;
    int c = 0;
    int lc = 0;
    int llc = 0;
    int motor_state = 0;
    


    while (1) {

        // polling loop thing
        currentTime = getTimeNow();
        
        
        
        if (message_incoming == 1){
           // LED3_Toggle();
            
            if (msg[2] == ACsystemID) {
                resetBuffer();
            } else if (msg[2] != IAsystemID && msg[2] != KDsystemID && msg[2] != AGsystemID) {
                resetBuffer();
            } else if (msg[3] == IAsystemID || msg[3] == KDsystemID || msg[3] == AGsystemID || msg[3] == 0x58) {
                printf("%s", msg);
                resetBuffer();
            } else if (msg[3] == ACsystemID) {
                //system analysis logic
                
                // stepper case
                if (msg[4] == '2') {
                    
                    direction = msg[5];
                    uint8_t movedeg;
                    movedeg = msg[6];
                    movecount = movedeg*(4096/360);
                    
                }
                
                
                
                // alignment freq case
                if(msg[4] == '3'){
                    
                    alignfreq = msg[5];
                   
                    LED3_Toggle();
                    
                   
                   
                }
                
                
            }
            else {//catchall
                resetBuffer();
            }
         

        
           message_incoming = 0;        
                    
        }
        
        
        
         
        
        if((currentTime - passedTime) >= 10.0){
            substatuscode();
            substatuserrormsg();
            
            
            //old motor code
            
//        motorin = IO_RD5_GetValue();
//        if(motorin == 1){
//            IO_RB3_SetLow();
//            temp = SPI1_ByteExchange(FWD);
//            // __delay_ms(2000); //for test
//            IO_RB3_SetHigh();
//            break;
//            }
//
//        if(motorin == 0){
//            IO_RB3_SetLow();
//            temp = SPI1_ByteExchange(STP);
//            // __delay_ms(2000); //for test
//            IO_RB3_SetHigh();
//            break;
//            }
//            
            
            //printf("%.2fB",passedTime); debug code
            
            passedTime = currentTime;
        }
        
        
        // new motor code
        
        
        if((currentTime - checTime ) >= 0.25){
                     
             checTime = currentTime;
             
             photoread[c] = IO_RD5_GetValue();
             
             if(photoread[c] == 0 && photoread[lc] == 0 && photoread[llc] == 0){
                 
                IO_RB3_SetLow();
                temp = SPI1_ByteExchange(FWD);
                IO_RB3_SetHigh();
                 
                 
                motor_state = 1;
                motorTime = currentTime;
                 
             }
             else if(photoread[c] == 1 && photoread[lc] == 1 && photoread[llc] == 1){
                 
                IO_RB3_SetLow();
                temp = SPI1_ByteExchange(REV);
                IO_RB3_SetHigh();
                 
                 
                motor_state = 1;
                motorTime = currentTime;
                 
             }
             
             llc = lc;
             lc = c;
             c++;
             
             if(c>2){
                 c = 0;
             }
             
             
        }
        
        if((currentTime - motorTime) >= 0.5){
            //motor off
            
            IO_RB3_SetLow();
            temp = SPI1_ByteExchange(STP);
            IO_RB3_SetHigh();
            
            motor_state = 0;
            
        }
        
        
        // stepper stuff
        if(stepcount < movecount){
        
            if ((currentTime - lastStepTime) >= stepDelay) {
                stepStepper();
                lastStepTime = currentTime;
                stepcount++;
            } 
        }
        else if(stepcount>=movecount){
            stepcount = 0;
            movecount = 0;
        }
        
    
    
        

        
        
    }
    
    
    
    
    
}